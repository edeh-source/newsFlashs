CKEDITOR.dtd.$removeEmpty['span'] = false;
CKEDITOR.config.allowedContent = true;
CKEDITOR.config.extraAllowedContent = 'span(*)';